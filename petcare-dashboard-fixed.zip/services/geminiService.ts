
import { GoogleGenAI, Type } from "@google/genai";
import { PetProfile, WellBeingScore, Alert, BehaviorDataPoint, BehaviorPrediction } from "../types";

// Standard client for basic tasks
const API_KEY = process.env.API_KEY || process.env.GEMINI_API_KEY || '';
const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

export const getSmartInsights = async (
  pet: PetProfile,
  score: WellBeingScore,
  alerts: Alert[]
) => {
  try {
    if (!ai) {
      return "API key not configured. Add your Gemini API key to enable AI insights.";
    }

    const breakdownStr = score.metrics.map(m => `${m.label}: ${m.value}/100`).join(', ');

    const prompt = `
      Act as a world-class veterinary behaviorist.
      Analyze this pet data:
      Pet: ${pet.name}, a ${pet.age}-year-old ${pet.breed}.
      Overall Well-being Score: ${score.overall}/100.
      Breakdown: ${breakdownStr}.
      Recent Alerts: ${alerts.map(a => a.cause).join('; ')}.

      Provide a 2-sentence empathetic summary of the pet's current state and one specific, actionable recommendation for the owner.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.7,
      }
    });

    return response.text || "Unable to generate insights at this time.";
  } catch (error) {
    console.error("Gemini API error:", error);
    return "Your pet is doing okay, but I can't provide detailed analysis right now.";
  }
};

/**
 * DEEP THINKING: Uses Gemini 3 Pro with max thinking budget for complex analysis.
 */
export const getDeepThinkingInsight = async (pet: PetProfile, score: WellBeingScore) => {
  if (!API_KEY) {
    return "API key not configured. Add your Gemini API key to enable deep analysis.";
  }

  const deepAi = new GoogleGenAI({ apiKey: API_KEY });
  const prompt = `Perform an exhaustive clinical and psychological analysis of ${pet.name} (${pet.breed}, ${pet.age}y). 
  Current Metrics: ${JSON.stringify(score.metrics)}. 
  Identify non-obvious correlations between physical health and emotional patterns. 
  Suggest a long-term wellness strategy that accounts for breed-specific predispositions and current score variations.`;

  try {
    const response = await deepAi.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }
      }
    });
    return response.text;
  } catch (error) {
    console.error("Deep Thinking Error:", error);
    return "The deep analysis module encountered an error. Please try again.";
  }
};

/**
 * SEARCH GROUNDING: Uses Google Search to find latest pet health trends or local info.
 */
export const getSearchGroundedTip = async (query: string) => {
  if (!ai) {
    return { text: "API key not configured.", sources: [] };
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: query,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    const text = response.text;
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    return { text, sources };
  } catch (error) {
    console.error("Search Grounding Error:", error);
    return { text: "Failed to fetch real-time data.", sources: [] };
  }
};

/**
 * VEO VIDEO GENERATION: Generate videos of your pet based on a prompt.
 */
export const generatePetVideo = async (prompt: string, aspectRatio: '16:9' | '9:16' = '16:9') => {
  if (!API_KEY) {
    throw new Error("API key not configured. Add your Gemini API key to enable video generation.");
  }

  const videoAi = new GoogleGenAI({ apiKey: API_KEY });
  try {
    let operation = await videoAi.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: aspectRatio
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await videoAi.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    const response = await fetch(`${downloadLink}&key=${API_KEY}`);
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  } catch (error) {
    console.error("Video Generation Error:", error);
    throw error;
  }
};

export const getBehavioralPrediction = async (
  pet: PetProfile,
  history: BehaviorDataPoint[]
): Promise<BehaviorPrediction | null> => {
  if (!ai) {
    console.warn("API key not configured for behavioral predictions");
    return null;
  }

  try {
    const historyStr = history.map(h => `${h.day}: Barking Score ${h.barking}, Activity ${h.activity}%, Rest ${h.rest}%`).join('; ');
    
    const prompt = `
      Act as an AI specialized in pet behavioral forecasting and veterinary psychology.
      
      CONTEXT:
      Pet: ${pet.name} (${pet.breed}, ${pet.age} years old).
      Historical Data (Last 7 Days): ${historyStr}.
      
      TASK:
      Analyze data and predict next 7 days. Return strictly JSON.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            prediction: { type: Type.STRING },
            riskLevel: { type: Type.STRING, enum: ['Low', 'Medium', 'High'] },
            explanation: { type: Type.STRING },
            preventiveAction: { type: Type.STRING }
          },
          required: ['prediction', 'riskLevel', 'explanation', 'preventiveAction']
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text.trim());
    }
    return null;
  } catch (error) {
    console.error("Behavior prediction error:", error);
    return null;
  }
};
