
import React, { useState } from 'react';
import { DaycareBooking, DaycareService, PetProfile } from '../types';
import { Calendar, Clock, MapPin, Plus, CheckCircle, X, Loader2, Dog, Briefcase, Sparkles, Trash2 } from 'lucide-react';
import { DAYCARE_SERVICES } from '../constants';

interface DaycareHubProps {
  pet: PetProfile;
  bookings: DaycareBooking[];
  onAddBooking: (booking: DaycareBooking) => void;
  onCancelBooking: (id: string) => void;
}

const DaycareHub: React.FC<DaycareHubProps> = ({ pet, bookings, onAddBooking, onCancelBooking }) => {
  const [isBooking, setIsBooking] = useState(false);
  const [selectedService, setSelectedService] = useState<DaycareService | null>(null);
  const [bookingDate, setBookingDate] = useState(new Date().toISOString().split('T')[0]);
  const [bookingTime, setBookingTime] = useState('08:00 AM');

  const handleCreateBooking = () => {
    if (!selectedService) return;
    
    const newBooking: DaycareBooking = {
      id: Math.random().toString(36).substr(2, 9),
      serviceName: selectedService.name,
      date: bookingDate,
      time: bookingTime,
      status: 'Scheduled',
      price: selectedService.price
    };
    
    onAddBooking(newBooking);
    setIsBooking(false);
    setSelectedService(null);
  };

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-500">
      {/* Header Info */}
      <div className="bg-orange-600 dark:bg-orange-700 p-8 md:p-12 rounded-[3rem] text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md border border-white/30">
              <Briefcase className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-black">Daycare & Play</h2>
          </div>
          <p className="text-white/90 text-lg font-bold leading-relaxed mb-8">
            Treat {pet.name} to a day of fun and socialization at our premium partner facilities. Expert care, 100% stress-free.
          </p>
          <div className="flex flex-wrap gap-4">
            <span className="px-5 py-2 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/20">Certified Staff</span>
            <span className="px-5 py-2 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/20">Live Cameras</span>
            <span className="px-5 py-2 bg-amber-400 text-orange-900 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">New Partner Added</span>
          </div>
        </div>
        <Dog className="absolute -bottom-20 -right-20 w-80 h-80 text-white/5 rotate-12" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Services List */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex items-center justify-between px-4">
            <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Available Services</h3>
            <span className="text-xs font-bold text-slate-400">Nearby Pawsburg Center</span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {DAYCARE_SERVICES.map((service) => (
              <div 
                key={service.id} 
                className="group bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 hover:border-orange-500 hover:shadow-xl transition-all cursor-pointer"
                onClick={() => {
                  setSelectedService(service);
                  setIsBooking(true);
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-2xl text-orange-600 group-hover:bg-orange-600 group-hover:text-white transition-colors">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <span className="text-lg font-black text-slate-900 dark:text-white">{service.price}</span>
                </div>
                <h4 className="text-lg font-black text-slate-900 dark:text-white mb-2">{service.name}</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mb-4 line-clamp-2">{service.description}</p>
                <div className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-400 tracking-widest border-t border-slate-50 dark:border-slate-800 pt-4">
                  <Clock className="w-3.5 h-3.5" /> {service.duration}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bookings Section */}
        <div className="lg:col-span-5 space-y-6">
          <div className="flex items-center justify-between px-4">
            <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Upcoming Visits</h3>
            <button className="text-[10px] font-black text-orange-600 uppercase tracking-widest hover:underline">View History</button>
          </div>

          <div className="space-y-4">
            {bookings.map((booking) => (
              <div key={booking.id} className="bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm group">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center justify-center text-slate-400">
                      <Calendar className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 dark:text-white">{booking.serviceName}</h4>
                      <p className="text-xs font-bold text-slate-400">{booking.date} at {booking.time}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-1 ${
                      booking.status === 'Scheduled' ? 'bg-indigo-50 text-indigo-600' :
                      booking.status === 'Checked-in' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {booking.status}
                    </div>
                    <p className="text-xs font-black text-slate-900 dark:text-white">{booking.price}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 py-3 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-colors">Modify</button>
                  <button 
                    onClick={() => onCancelBooking(booking.id)}
                    className="px-4 py-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            {bookings.length === 0 && (
              <div className="py-20 text-center bg-white dark:bg-slate-900 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-[3rem]">
                <Calendar className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <p className="text-slate-400 font-bold italic">No visits scheduled yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      {isBooking && selectedService && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setIsBooking(false)} />
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl p-8 md:p-10 animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-black text-slate-900 dark:text-white">Book Session</h2>
              <button onClick={() => setIsBooking(false)} className="p-2 hover:bg-slate-100 rounded-xl"><X className="w-6 h-6 text-slate-400" /></button>
            </div>

            <div className="space-y-6">
              <div className="p-6 bg-orange-50 dark:bg-orange-950/20 rounded-[2rem] border border-orange-100 dark:border-orange-900/30">
                <h3 className="text-lg font-black text-orange-800 dark:text-orange-400 mb-1">{selectedService.name}</h3>
                <p className="text-sm font-bold text-orange-600/80">{selectedService.price} • {selectedService.duration}</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Select Date</label>
                  <input 
                    type="date" 
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Arrival Time</label>
                  <select 
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                    value={bookingTime}
                    onChange={(e) => setBookingTime(e.target.value)}
                  >
                    <option>08:00 AM</option>
                    <option>09:00 AM</option>
                    <option>10:00 AM</option>
                    <option>01:00 PM</option>
                  </select>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between mb-8">
                  <span className="text-slate-500 font-black uppercase text-[10px] tracking-widest">Total Due</span>
                  <span className="text-3xl font-black text-slate-900 dark:text-white">{selectedService.price}</span>
                </div>
                <button 
                  onClick={handleCreateBooking}
                  className="w-full py-5 bg-orange-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-orange-100 flex items-center justify-center gap-3"
                >
                  Confirm Booking <CheckCircle className="w-6 h-6" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DaycareHub;
