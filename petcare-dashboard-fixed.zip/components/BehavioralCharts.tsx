
import React from 'react';
import { BehaviorDataPoint, BehaviorPrediction } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { BrainCircuit, Sparkles, ShieldAlert, RefreshCw, Info, CheckCircle2 } from 'lucide-react';

interface BehavioralChartsProps {
  data: BehaviorDataPoint[];
  prediction: BehaviorPrediction | null;
  isPredicting: boolean;
  onRefreshPrediction: () => void;
}

const BehavioralCharts: React.FC<BehavioralChartsProps> = ({ data, prediction, isPredicting, onRefreshPrediction }) => {
  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 transition-all hover:shadow-md">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-xl font-bold text-slate-900">Behavioral Analytics</h2>
            <div className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-md text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Live Sync
            </div>
          </div>
          <p className="text-sm text-slate-500">Correlation between activity, vocalization, and rest</p>
        </div>
        <div className="flex p-1 bg-slate-50 rounded-xl">
          <button className="px-4 py-1.5 bg-white shadow-sm text-indigo-600 rounded-lg text-xs font-bold transition-all">7 Days</button>
          <button className="px-4 py-1.5 text-slate-400 rounded-lg text-xs font-bold hover:text-slate-600 transition-all">30 Days</button>
        </div>
      </div>

      <div className="h-[300px] w-full mb-8">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorActivity" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.15}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorBarking" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.15}/>
                <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} axisLine={false} tickLine={false} />
            <YAxis stroke="#94a3b8" fontSize={11} axisLine={false} tickLine={false} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)' }}
              cursor={{ stroke: '#e2e8f0', strokeWidth: 1 }}
            />
            <Legend verticalAlign="top" align="right" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }}/>
            <Area 
              type="monotone" 
              dataKey="activity" 
              name="Activity Level"
              stroke="#6366f1" 
              fillOpacity={1} 
              fill="url(#colorActivity)" 
              strokeWidth={3}
              animationDuration={1500}
            />
            <Area 
              type="monotone" 
              dataKey="barking" 
              name="Barking Intensity"
              stroke="#f43f5e" 
              fillOpacity={1} 
              fill="url(#colorBarking)" 
              strokeWidth={3}
              animationDuration={1500}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      {/* AI Prediction Module */}
      <div className="relative group">
        <div className={`absolute -inset-0.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-3xl blur ${isPredicting ? 'opacity-40 animate-pulse' : 'opacity-10'} group-hover:opacity-30 transition duration-1000`}></div>
        <div className="relative bg-white border border-indigo-50 rounded-2xl p-6 overflow-hidden">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-xl transition-colors ${isPredicting ? 'bg-indigo-600 text-white animate-spin-slow' : 'bg-slate-900 text-white'}`}>
                <BrainCircuit className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest italic leading-none mb-1">AI Behavior Forecast</h4>
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-bold uppercase">
                  <Sparkles className="w-3 h-3 text-indigo-400" /> Grounded in 7 Days History
                </div>
              </div>
            </div>
            <button 
              onClick={onRefreshPrediction}
              disabled={isPredicting}
              className={`p-2 rounded-xl border border-slate-100 transition-all ${isPredicting ? 'bg-slate-50 text-slate-300' : 'bg-white text-slate-600 hover:text-indigo-600 hover:border-indigo-100 shadow-sm'}`}
            >
              <RefreshCw className={`w-4 h-4 ${isPredicting ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {isPredicting || !prediction ? (
            <div className="space-y-4">
              <div className="flex flex-col gap-2">
                <div className="h-4 w-3/4 bg-slate-100 rounded animate-pulse"></div>
                <div className="h-3 w-1/2 bg-slate-50 rounded animate-pulse"></div>
              </div>
              <div className="h-16 w-full bg-indigo-50/30 rounded-xl border border-indigo-100/50 animate-pulse"></div>
              <p className="text-[10px] text-center font-black text-indigo-400 uppercase tracking-widest animate-bounce mt-2">
                Running Predictive Models...
              </p>
            </div>
          ) : (
            <div className="space-y-5 animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <p className="text-base font-bold text-slate-800 mb-1 leading-tight">
                    {prediction.prediction}
                  </p>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 leading-relaxed italic">
                    <Info className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                    <span>{prediction.explanation}</span>
                  </div>
                </div>
                <div className={`px-3 py-1.5 rounded-xl border text-[10px] font-black uppercase tracking-wider shrink-0 ${
                  prediction.riskLevel === 'High' ? 'bg-red-50 text-red-600 border-red-100' : 
                  prediction.riskLevel === 'Medium' ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-emerald-50 text-emerald-600 border-emerald-100'
                }`}>
                  {prediction.riskLevel} Risk
                </div>
              </div>
              
              <div className="bg-indigo-900 rounded-2xl p-4 shadow-inner">
                <div className="flex items-center gap-2 text-indigo-300 mb-2">
                  <ShieldAlert className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Recommended Strategy</span>
                </div>
                <p className="text-sm font-bold text-white leading-relaxed">
                  {prediction.preventiveAction}
                </p>
              </div>

              <div className="flex items-center justify-between border-t border-slate-50 pt-4">
                <div className="flex -space-x-2">
                  <div className="w-6 h-6 rounded-full bg-indigo-500 border-2 border-white flex items-center justify-center text-[8px] font-bold text-white">AI</div>
                  <div className="w-6 h-6 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center text-[8px] font-bold text-white">7D</div>
                </div>
                <span className="text-[10px] font-bold text-slate-400">Analysis updated just now</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BehavioralCharts;
