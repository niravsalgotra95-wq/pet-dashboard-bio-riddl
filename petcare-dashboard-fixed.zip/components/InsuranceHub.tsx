
import React, { useState } from 'react';
import { InsurancePolicy, InsuranceClaim } from '../types';
import { ShieldCheck, Plus, FileText, Clock, CheckCircle, XCircle, AlertCircle, Trash2, Calendar, DollarSign, Edit3, X } from 'lucide-react';

interface InsuranceHubProps {
  policy: InsurancePolicy;
  onUpdatePolicy: (policy: InsurancePolicy) => void;
}

const InsuranceHub: React.FC<InsuranceHubProps> = ({ policy, onUpdatePolicy }) => {
  const [isAddingClaim, setIsAddingClaim] = useState(false);
  const [isEditingPolicy, setIsEditingPolicy] = useState(false);
  const [editedPolicy, setEditedPolicy] = useState<InsurancePolicy>(policy);
  const [newClaim, setNewClaim] = useState<Partial<InsuranceClaim>>({
    description: '',
    amount: '',
    date: new Date().toISOString().split('T')[0]
  });

  const handleAddClaim = () => {
    if (!newClaim.description || !newClaim.amount) return;
    const claim: InsuranceClaim = {
      id: Math.random().toString(36).substr(2, 9),
      date: newClaim.date || '',
      amount: `$${newClaim.amount}`,
      description: newClaim.description || '',
      status: 'Processing'
    };
    onUpdatePolicy({ ...policy, claims: [...policy.claims, claim] });
    setIsAddingClaim(false);
    setNewClaim({ description: '', amount: '', date: new Date().toISOString().split('T')[0] });
  };

  const handleSavePolicy = () => {
    onUpdatePolicy(editedPolicy);
    setIsEditingPolicy(false);
  };

  const deleteClaim = (id: string) => {
    onUpdatePolicy({ ...policy, claims: policy.claims.filter(c => c.id !== id) });
  };

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Policy Details Card */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] md:rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl">
                <ShieldCheck className="w-8 h-8 text-emerald-600" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white leading-none">Policy</h2>
                <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">{policy.status}</span>
              </div>
            </div>
            <button 
              onClick={() => setIsEditingPolicy(true)}
              className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-400 hover:text-orange-600 transition-colors"
            >
              <Edit3 className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6">
            <div className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-[1.5rem] border border-slate-100 dark:border-slate-800">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Carrier</p>
              <p className="text-xl font-black text-slate-900 dark:text-white">{policy.provider}</p>
              <p className="text-xs font-bold text-slate-400 mt-1">ID: {policy.policyNumber}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-[1.5rem] border border-slate-100 dark:border-slate-800">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Annual Limit</p>
                <p className="font-black text-slate-900 dark:text-white">{policy.coverageLimit}</p>
              </div>
              <div className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-[1.5rem] border border-slate-100 dark:border-slate-800">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Monthly Cost</p>
                <p className="font-black text-slate-900 dark:text-white">{policy.premium}</p>
              </div>
            </div>

            <button className="w-full py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all">
              Manage Digital Wallet ID
            </button>
          </div>
        </div>

        {/* Claims History */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 md:p-10 rounded-[2.5rem] md:rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-10 gap-6">
            <div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">Expense Reimbursement</h2>
              <p className="text-sm text-slate-500 font-bold italic">Quick approval for medical claims</p>
            </div>
            <button 
              onClick={() => setIsAddingClaim(true)}
              className="w-full sm:w-auto flex items-center justify-center gap-3 px-8 py-4 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-orange-100 dark:shadow-none hover:scale-105 active:scale-95 transition-all"
            >
              <Plus className="w-5 h-5" /> Start New Claim
            </button>
          </div>

          <div className="space-y-4">
            {policy.claims.map((claim) => (
              <div key={claim.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-6 bg-slate-50 dark:bg-slate-800/40 rounded-[2rem] border border-slate-100 dark:border-slate-800 gap-5 group transition-all hover:border-orange-200">
                <div className="flex items-center gap-5">
                  <div className={`p-4 rounded-2xl shadow-sm ${
                    claim.status === 'Approved' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40' :
                    claim.status === 'Rejected' ? 'bg-red-100 text-red-600 dark:bg-red-950/40' : 'bg-amber-100 text-amber-600 dark:bg-amber-950/40'
                  }`}>
                    {claim.status === 'Approved' ? <CheckCircle className="w-6 h-6" /> :
                     claim.status === 'Rejected' ? <XCircle className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
                  </div>
                  <div>
                    <h4 className="font-black text-slate-900 dark:text-white mb-1">{claim.description}</h4>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{claim.date}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between sm:justify-end gap-10 border-t sm:border-t-0 pt-4 sm:pt-0">
                  <div className="text-left sm:text-right">
                    <p className="text-xl font-black text-slate-900 dark:text-white">{claim.amount}</p>
                    <p className="text-[10px] font-black uppercase text-slate-400">{claim.status}</p>
                  </div>
                  <button onClick={() => deleteClaim(claim.id)} className="p-2.5 bg-white dark:bg-slate-900 rounded-xl text-slate-300 hover:text-red-500 shadow-sm transition-all">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            {policy.claims.length === 0 && (
              <div className="py-24 text-center border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-[3rem]">
                <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <FileText className="w-8 h-8 text-slate-200" />
                </div>
                <p className="text-slate-400 font-bold italic">No medical claims found.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Policy Modal */}
      {isEditingPolicy && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setIsEditingPolicy(false)} />
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl p-10 animate-in zoom-in-95 duration-300">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-8">Update Policy</h2>
            <div className="space-y-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Provider Name</label>
                <input 
                  type="text" 
                  className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                  value={editedPolicy.provider}
                  onChange={(e) => setEditedPolicy({...editedPolicy, provider: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Limit</label>
                  <input 
                    type="text" 
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                    value={editedPolicy.coverageLimit}
                    onChange={(e) => setEditedPolicy({...editedPolicy, coverageLimit: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Premium</label>
                  <input 
                    type="text" 
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                    value={editedPolicy.premium}
                    onChange={(e) => setEditedPolicy({...editedPolicy, premium: e.target.value})}
                  />
                </div>
              </div>
              <div className="flex gap-4 pt-6">
                <button onClick={handleSavePolicy} className="flex-1 py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black shadow-xl active:scale-95 transition-all">Save Changes</button>
                <button onClick={() => setIsEditingPolicy(false)} className="px-10 py-5 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-2xl font-black">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Claim Modal */}
      {isAddingClaim && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setIsAddingClaim(false)} />
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl p-8 md:p-12 animate-in zoom-in-95 duration-300">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-8">Submit Reimbursement</h2>
            
            <div className="space-y-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase px-2 tracking-widest">Description</label>
                <input 
                  type="text" 
                  placeholder="e.g. Wellness Exam & Vaccinations"
                  className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                  value={newClaim.description}
                  onChange={(e) => setNewClaim({...newClaim, description: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase px-2 tracking-widest">Cost ($)</label>
                  <input 
                    type="number" 
                    placeholder="150.00"
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                    value={newClaim.amount}
                    onChange={(e) => setNewClaim({...newClaim, amount: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Date</label>
                  <input 
                    type="date" 
                    className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-transparent focus:border-orange-500 outline-none dark:text-white"
                    value={newClaim.date}
                    onChange={(e) => setNewClaim({...newClaim, date: e.target.value})}
                  />
                </div>
              </div>

              <div className="p-5 bg-amber-50 dark:bg-amber-950/20 rounded-2xl border border-amber-100 dark:border-amber-900/30 flex gap-4">
                <AlertCircle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-[11px] font-bold text-amber-800 dark:text-amber-400 leading-relaxed">Please ensure high-quality photo of your receipt is uploaded in the next step. Payments are issued via Direct Deposit.</p>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  onClick={handleAddClaim}
                  className="flex-1 py-5 bg-orange-600 text-white rounded-[1.5rem] font-black text-lg shadow-xl shadow-orange-100 active:scale-95 transition-all"
                >
                  Review & Submit
                </button>
                <button 
                  onClick={() => setIsAddingClaim(false)}
                  className="px-8 py-5 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-[1.5rem] font-black"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InsuranceHub;
