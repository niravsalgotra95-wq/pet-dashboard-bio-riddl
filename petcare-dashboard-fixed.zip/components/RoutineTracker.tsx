
import React, { useState } from 'react';
import { RoutineItem, RoutineType, PetCategory } from '../types';
import { 
  CheckCircle2, Clock, Pill, Footprints, Utensils, PlayCircle, 
  X, Check, Droplets, Waves, Filter, Moon
} from 'lucide-react';

interface RoutineTrackerProps {
  routine: RoutineItem[];
  petCategory: PetCategory;
  onUpdate: (updated: RoutineItem[]) => void;
}

const RoutineTracker: React.FC<RoutineTrackerProps> = ({ routine, petCategory, onUpdate }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState<Partial<RoutineItem>>({
    title: '',
    time: '',
    type: petCategory === 'Fish' ? 'Feeding' : 'Walk',
    status: 'Upcoming'
  });

  const getIcon = (type: RoutineType) => {
    switch (type) {
      case 'Feeding': return <Utensils className="w-4 h-4" />;
      case 'Walk': return <Footprints className="w-4 h-4" />;
      case 'Play': return <PlayCircle className="w-4 h-4" />;
      case 'Medicine': return <Pill className="w-4 h-4" />;
      case 'Sleep': return <Moon className="w-4 h-4" />;
      case 'Tank Cleaning': return <Waves className="w-4 h-4" />;
      case 'Water Change': return <Droplets className="w-4 h-4" />;
      case 'Filter Check': return <Filter className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: RoutineType) => {
    if (['Tank Cleaning', 'Water Change', 'Filter Check'].includes(type)) {
      return 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-600 dark:text-cyan-400 border-cyan-100 dark:border-cyan-900/30';
    }
    return 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400 border border-orange-100 dark:border-orange-900/30';
  };

  const handleToggleStatus = (id: string) => {
    const updated = routine.map(item => {
      if (item.id === id) {
        const nextStatus = item.status === 'Completed' ? 'Upcoming' : 'Completed';
        return { ...item, status: nextStatus };
      }
      return item;
    });
    onUpdate(updated as RoutineItem[]);
  };

  const handleSave = () => {
    if (!formData.title || !formData.time) return;

    const newItem: RoutineItem = {
      id: Date.now().toString(),
      title: formData.title || '',
      time: formData.time || '',
      type: formData.type as RoutineType || 'Feeding',
      status: 'Upcoming'
    };
    onUpdate([...routine, newItem]);
    resetForm();
  };

  const resetForm = () => {
    setIsAdding(false);
    setFormData({ title: '', time: '', type: petCategory === 'Fish' ? 'Feeding' : 'Walk', status: 'Upcoming' });
  };

  const completionRate = Math.round((routine.filter(r => r.status === 'Completed').length / (routine.length || 1)) * 100);

  // Determine available options based on category
  const aquaticTypes: RoutineType[] = ['Feeding', 'Medicine', 'Tank Cleaning', 'Water Change', 'Filter Check'];
  const mammalTypes: RoutineType[] = ['Feeding', 'Walk', 'Play', 'Sleep', 'Medicine'];
  
  const availableTypes = petCategory === 'Fish' ? aquaticTypes : mammalTypes;

  return (
    <div className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] shadow-sm border border-slate-100 dark:border-slate-800 transition-colors duration-300">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-xl font-black text-slate-900 dark:text-white">Daily Routine</h2>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-xl text-[10px] font-black uppercase tracking-widest border border-emerald-100 dark:border-emerald-800">
          <CheckCircle2 className="w-4 h-4" />
          {completionRate}% Done
        </div>
      </div>

      <div className="space-y-4">
        {routine.map((item) => (
          <div 
            key={item.id} 
            className={`group relative flex items-center gap-5 p-5 rounded-[1.5rem] transition-all cursor-pointer border ${
              item.status === 'Completed' 
                ? 'bg-slate-50 dark:bg-slate-800/40 border-transparent grayscale opacity-60' 
                : 'bg-white dark:bg-slate-900 border-slate-50 dark:border-slate-800 hover:border-orange-200 dark:hover:border-orange-900/50 shadow-sm'
            }`}
            onClick={() => handleToggleStatus(item.id)}
          >
            <div className={`p-3 rounded-2xl transition-all ${
              item.status === 'Completed' ? 'bg-slate-200 text-slate-500 dark:bg-slate-700' : getTypeColor(item.type)
            }`}>
              {getIcon(item.type)}
            </div>
            
            <div className="flex-1">
              <h3 className={`text-base font-black ${item.status === 'Completed' ? 'text-slate-400 line-through' : 'text-slate-900 dark:text-white'}`}>
                {item.title}
              </h3>
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mt-0.5">{item.time}</p>
            </div>

            <div className={`w-7 h-7 rounded-xl border-2 flex items-center justify-center transition-all ${
                item.status === 'Completed' 
                  ? 'bg-emerald-500 border-emerald-500 shadow-lg shadow-emerald-100 dark:shadow-none' 
                  : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 group-hover:border-orange-400'
              }`}>
              {item.status === 'Completed' && <Check className="w-4 h-4 text-white" />}
            </div>
          </div>
        ))}

        {routine.length === 0 && !isAdding && (
          <div className="py-12 text-center border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-3xl">
             <Clock className="w-8 h-8 text-slate-200 dark:text-slate-800 mx-auto mb-3" />
             <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">No activities scheduled</p>
          </div>
        )}
      </div>

      {isAdding ? (
        <div className="mt-8 p-6 border-2 border-orange-100 dark:border-orange-900/30 bg-orange-50/30 dark:bg-orange-900/10 rounded-[2rem] animate-in fade-in slide-in-from-top-6 duration-300">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-black uppercase tracking-widest text-orange-700 dark:text-orange-400">Add Entry</h3>
            <button onClick={resetForm} className="p-1 hover:bg-orange-100 rounded-lg transition-colors">
              <X className="w-5 h-5 text-orange-400" />
            </button>
          </div>
          
          <div className="space-y-4">
            <input 
              type="text" 
              placeholder={`Event name (e.g. ${petCategory === 'Fish' ? 'Morning Feeding' : 'Afternoon Walk'})`}
              className="w-full px-5 py-4 text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl focus:outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all"
              value={formData.title}
              onChange={e => setFormData({...formData, title: e.target.value})}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <input 
                type="text" 
                placeholder="Time (e.g. 2 PM)"
                className="w-full px-5 py-4 text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl focus:outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all"
                value={formData.time}
                onChange={e => setFormData({...formData, time: e.target.value})}
              />
              <select 
                className="w-full px-5 py-4 text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl focus:outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white outline-none"
                value={formData.type}
                onChange={e => setFormData({...formData, type: e.target.value as RoutineType})}
              >
                {availableTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <button 
              onClick={handleSave}
              className="w-full py-5 bg-orange-600 text-white text-sm font-black uppercase tracking-widest rounded-2xl hover:bg-orange-700 transition-all shadow-xl shadow-orange-100 dark:shadow-none active:scale-95"
            >
              Confirm Entry
            </button>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsAdding(true)}
          className="w-full mt-8 py-5 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl text-xs font-black uppercase tracking-widest text-slate-400 dark:text-slate-600 hover:border-orange-400 hover:text-orange-500 hover:bg-orange-50 dark:hover:bg-orange-900/10 transition-all"
        >
          + Add Routine Event
        </button>
      )}
    </div>
  );
};

export default RoutineTracker;
