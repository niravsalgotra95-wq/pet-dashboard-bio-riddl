
import React, { useState } from 'react';
import { generatePetVideo } from '../services/geminiService';
import { PetVideo } from '../types';
import { Video, Sparkles, Send, Loader2, Play, Download, Trash2, Camera } from 'lucide-react';

interface VideoCreatorProps {
  videos: PetVideo[];
  onAddVideo: (video: PetVideo) => void;
  onDeleteVideo: (id: string) => void;
}

const VideoCreator: React.FC<VideoCreatorProps> = ({ videos, onAddVideo, onDeleteVideo }) => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  const messages = [
    "Preparing the cinematic lens...",
    "Training our digital actors...",
    "Rendering pet fur physics...",
    "Capturing the perfect playful moment...",
    "Almost ready for the premiere!"
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    let msgIdx = 0;
    const interval = setInterval(() => {
      setStatusMsg(messages[msgIdx % messages.length]);
      msgIdx++;
    }, 4000);

    try {
      const url = await generatePetVideo(prompt);
      const newVideo: PetVideo = {
        id: Date.now().toString(),
        prompt: prompt,
        videoUrl: url,
        timestamp: new Date().toLocaleString()
      };
      onAddVideo(newVideo);
      setPrompt('');
    } catch (err) {
      alert("Failed to generate video. Ensure you have a valid paid API key configured in Settings.");
    } finally {
      clearInterval(interval);
      setIsGenerating(false);
      setStatusMsg('');
    }
  };

  return (
    <div className="space-y-8 pb-20 animate-in fade-in duration-500">
      <div className="bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800 text-center">
        <div className="max-w-2xl mx-auto">
          <div className="w-20 h-20 bg-orange-600 rounded-[2rem] flex items-center justify-center shadow-xl shadow-orange-100 mx-auto mb-8">
            <Video className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-4xl font-black text-slate-900 dark:text-white mb-4">Veo 3 Pet Cinema</h2>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-lg mb-10 leading-relaxed">
            Create high-quality cinematic videos of your pet using just your imagination. Powered by Veo 3.
          </p>

          <div className="relative group mb-4">
            <textarea 
              placeholder="A golden retriever playing with a blue frisbee on a neon beach at sunset, cinematic lighting, 4k..."
              className="w-full h-32 px-6 py-6 bg-slate-50 dark:bg-slate-800 rounded-[2rem] border-2 border-transparent focus:border-orange-500 outline-none dark:text-white font-medium resize-none transition-all shadow-inner"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              disabled={isGenerating}
            />
            <button 
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="absolute bottom-4 right-4 p-4 bg-orange-600 text-white rounded-2xl shadow-xl hover:scale-105 active:scale-95 disabled:opacity-50 disabled:grayscale transition-all flex items-center gap-3"
            >
              {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              <span className="font-black uppercase text-xs tracking-widest hidden sm:inline">Action!</span>
            </button>
          </div>
          
          {isGenerating && (
            <div className="mt-4 flex items-center justify-center gap-3 text-orange-600 font-black text-sm animate-pulse">
              <Camera className="w-5 h-5" />
              <span>{statusMsg}</span>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {videos.map((vid) => (
          <div key={vid.id} className="group relative bg-white dark:bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-sm border border-slate-100 dark:border-slate-800 hover:shadow-2xl transition-all">
            <div className="aspect-[16/9] bg-slate-900 relative">
              <video 
                src={vid.videoUrl} 
                className="w-full h-full object-cover" 
                controls
              />
            </div>
            <div className="p-6">
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300 line-clamp-2 mb-4 leading-relaxed italic">
                "{vid.prompt}"
              </p>
              <div className="flex items-center justify-between border-t border-slate-50 dark:border-slate-800 pt-4">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{vid.timestamp}</span>
                <div className="flex gap-2">
                  <a href={vid.videoUrl} download={`pet-video-${vid.id}.mp4`} className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-400 hover:text-orange-600 transition-colors">
                    <Download className="w-4 h-4" />
                  </a>
                  <button onClick={() => onDeleteVideo(vid.id)} className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-400 hover:text-red-500 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {videos.length === 0 && !isGenerating && (
          <div className="col-span-full py-20 text-center border-4 border-dashed border-slate-100 dark:border-slate-800 rounded-[4rem]">
            <Play className="w-16 h-16 text-slate-100 dark:text-slate-800 mx-auto mb-6" />
            <p className="text-slate-400 font-bold italic">No masterpieces yet. Type a prompt above to start filming!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoCreator;
