
import React, { useState } from 'react';
import { VetProfile } from '../types';
import { Plus, Edit2, Trash2, Phone, Mail, MapPin, X, ShieldAlert, Stethoscope, PlusCircle, Image as ImageIcon, Search } from 'lucide-react';

interface VetHubProps {
  vets: VetProfile[];
  onSave: (vet: VetProfile) => void;
  onDelete: (id: string) => void;
}

const VetHub: React.FC<VetHubProps> = ({ vets, onSave, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentVet, setCurrentVet] = useState<Partial<VetProfile>>({
    name: '',
    clinic: '',
    address: '',
    specialty: '',
    phone: '',
    email: '',
    isEmergency: false,
    imageUrl: 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&q=80&w=200&h=200'
  });

  const handleEdit = (vet?: VetProfile) => {
    if (vet) {
      setCurrentVet(vet);
    } else {
      setCurrentVet({
        name: '',
        clinic: '',
        address: '',
        specialty: '',
        phone: '',
        email: '',
        isEmergency: false,
        imageUrl: 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&q=80&w=200&h=200'
      });
    }
    setIsEditing(true);
  };

  const handleSave = () => {
    if (!currentVet.name || !currentVet.clinic) {
      alert("Name and Clinic are required fields.");
      return;
    }
    const vetToSave = {
      ...currentVet,
      id: currentVet.id || Date.now().toString(),
    } as VetProfile;
    onSave(vetToSave);
    setIsEditing(false);
  };

  const filteredVets = vets.filter(v => 
    v.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    v.clinic.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800 transition-colors duration-300">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-4 mb-2">
              <div className="p-4 bg-orange-100 dark:bg-orange-900/30 rounded-[1.25rem]">
                <Stethoscope className="w-7 h-7 text-orange-600 dark:text-orange-400" />
              </div>
              <div>
                <h2 className="text-3xl font-black text-slate-900 dark:text-white">Healthcare Network</h2>
                <p className="text-slate-500 dark:text-slate-400 font-bold">Manage your pet's veterinarians and specialists</p>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search providers..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-11 pr-6 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all w-full sm:w-64"
              />
            </div>
            {!isEditing && (
              <button 
                onClick={() => handleEdit()}
                className="flex items-center justify-center gap-3 px-8 py-4 bg-orange-600 text-white rounded-2xl font-black shadow-xl shadow-orange-100 dark:shadow-none hover:bg-orange-700 active:scale-95 transition-all"
              >
                <PlusCircle className="w-5 h-5" /> Add Provider
              </button>
            )}
          </div>
        </div>

        {isEditing && (
          <div className="mb-16 p-8 bg-orange-50/20 dark:bg-slate-800/50 rounded-[2.5rem] border border-orange-100 dark:border-slate-700 animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-center mb-10">
              <div className="flex items-center gap-3">
                <div className="w-2 h-8 bg-orange-500 rounded-full" />
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">{currentVet.id ? 'Edit Information' : 'Register New Provider'}</h3>
              </div>
              <button onClick={() => setIsEditing(false)} className="p-3 bg-white dark:bg-slate-900 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors border border-slate-100 dark:border-slate-700 shadow-sm"><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-1.5 lg:col-span-2">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-2">Professional Name</label>
                <input 
                  className="w-full px-5 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all" 
                  placeholder="e.g. Dr. Jordan Smith" 
                  value={currentVet.name} 
                  onChange={e => setCurrentVet({...currentVet, name: e.target.value})} 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-2">Provider Type / Specialty</label>
                <input 
                  className="w-full px-5 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all" 
                  placeholder="e.g. Behavioralist, Surgeon" 
                  value={currentVet.specialty} 
                  onChange={e => setCurrentVet({...currentVet, specialty: e.target.value})} 
                />
              </div>
              <div className="space-y-1.5 lg:col-span-3">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-2">Clinic or Hospital Name</label>
                <input 
                  className="w-full px-5 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all" 
                  placeholder="e.g. Central Veterinary Hospital" 
                  value={currentVet.clinic} 
                  onChange={e => setCurrentVet({...currentVet, clinic: e.target.value})} 
                />
              </div>
              <div className="space-y-1.5 lg:col-span-3">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-2">Full Clinic Address</label>
                <input 
                  className="w-full px-5 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all" 
                  placeholder="Street address, City, State, ZIP" 
                  value={currentVet.address} 
                  onChange={e => setCurrentVet({...currentVet, address: e.target.value})} 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-2">Primary Phone</label>
                <input 
                  className="w-full px-5 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all" 
                  placeholder="(555) 000-0000" 
                  value={currentVet.phone} 
                  onChange={e => setCurrentVet({...currentVet, phone: e.target.value})} 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-2">Email Address</label>
                <input 
                  className="w-full px-5 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all" 
                  placeholder="contact@clinic.com" 
                  value={currentVet.email} 
                  onChange={e => setCurrentVet({...currentVet, email: e.target.value})} 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-2">Photo URL</label>
                <div className="relative">
                  <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    className="w-full pl-11 pr-5 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/20 dark:text-white transition-all" 
                    placeholder="https://..." 
                    value={currentVet.imageUrl} 
                    onChange={e => setCurrentVet({...currentVet, imageUrl: e.target.value})} 
                  />
                </div>
              </div>
            </div>

            <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-6">
              <label className="flex items-center gap-4 px-8 py-5 bg-white dark:bg-slate-900 rounded-[1.5rem] border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-red-50 dark:hover:bg-red-950/20 transition-all select-none group w-full sm:w-auto shadow-sm">
                <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${currentVet.isEmergency ? 'bg-red-500 border-red-500 shadow-lg shadow-red-200' : 'border-slate-300 dark:border-slate-600'}`}>
                   {currentVet.isEmergency && <ShieldAlert className="w-4 h-4 text-white" />}
                </div>
                <input type="checkbox" className="hidden" checked={currentVet.isEmergency} onChange={e => setCurrentVet({...currentVet, isEmergency: e.target.checked})} />
                <span className={`text-sm font-black uppercase tracking-wider ${currentVet.isEmergency ? 'text-red-600' : 'text-slate-600 dark:text-slate-400'}`}>Emergency Provider</span>
              </label>
              
              <div className="flex gap-4 w-full sm:w-auto">
                <button onClick={handleSave} className="flex-1 sm:flex-none px-12 py-5 bg-orange-600 text-white rounded-2xl font-black text-base shadow-xl shadow-orange-100 dark:shadow-none hover:bg-orange-700 active:scale-[0.98] transition-all">
                  {currentVet.id ? 'Save Changes' : 'Register Provider'}
                </button>
                <button onClick={() => setIsEditing(false)} className="flex-1 sm:flex-none px-8 py-5 bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded-2xl font-black text-sm hover:bg-slate-100 transition-all">Cancel</button>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredVets.map(vet => (
            <div key={vet.id} className={`p-8 rounded-[3rem] border transition-all group relative hover:shadow-2xl overflow-hidden ${vet.isEmergency ? 'bg-red-50/20 dark:bg-red-950/10 border-red-200 dark:border-red-900/30 shadow-lg shadow-red-50 dark:shadow-none' : 'bg-slate-50 dark:bg-slate-800/50 border-slate-100 dark:border-slate-700 shadow-sm'}`}>
              
              {/* Card Background Decoration */}
              {vet.isEmergency && <div className="absolute top-0 right-0 w-32 h-32 bg-red-100 dark:bg-red-900/20 rounded-full -mr-16 -mt-16 blur-3xl opacity-50" />}
              
              <div className="absolute top-8 right-8 flex gap-3 opacity-0 group-hover:opacity-100 transition-all scale-95 group-hover:scale-100 z-20">
                <button onClick={() => handleEdit(vet)} className="p-3 bg-white dark:bg-slate-900 text-slate-400 hover:text-orange-600 rounded-xl shadow-md border border-slate-100 dark:border-slate-700 transition-all"><Edit2 className="w-4 h-4" /></button>
                <button onClick={() => onDelete(vet.id)} className="p-3 bg-white dark:bg-slate-900 text-slate-400 hover:text-red-600 rounded-xl shadow-md border border-slate-100 dark:border-slate-700 transition-all"><Trash2 className="w-4 h-4" /></button>
              </div>

              <div className="flex flex-col sm:flex-row gap-8 relative z-10">
                <div className="relative shrink-0 mx-auto sm:mx-0">
                  <img 
                    src={vet.imageUrl} 
                    className={`w-36 h-36 rounded-[2.5rem] object-cover ring-8 shadow-2xl transition-all ${vet.isEmergency ? 'ring-red-100 dark:ring-red-950/30' : 'ring-white dark:ring-slate-900'}`} 
                    alt={vet.name} 
                  />
                  {vet.isEmergency && (
                    <div className="absolute -bottom-2 -right-2 p-3 bg-red-600 text-white rounded-2xl shadow-xl border-4 border-white dark:border-slate-900 animate-pulse">
                      <ShieldAlert className="w-6 h-6" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1 flex flex-col justify-center text-center sm:text-left">
                  <div className="mb-4">
                    <h3 className="font-black text-2xl text-slate-900 dark:text-white mb-1 leading-tight group-hover:text-orange-600 transition-colors">{vet.name}</h3>
                    <p className="text-sm font-black text-orange-600 dark:text-orange-400 uppercase tracking-widest">{vet.clinic}</p>
                  </div>
                  
                  <div className="space-y-3 mb-8">
                    <div className="flex items-center gap-3 text-xs font-bold text-slate-500 dark:text-slate-400 bg-white/60 dark:bg-black/20 p-3 rounded-2xl border border-slate-100/50 dark:border-slate-800/50">
                      <MapPin className="w-4 h-4 text-orange-400 shrink-0" />
                      <span className="truncate">{vet.address || 'Address not listed'}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs font-bold text-slate-500 dark:text-slate-400 bg-white/60 dark:bg-black/20 p-3 rounded-2xl border border-slate-100/50 dark:border-slate-800/50">
                      <Stethoscope className="w-4 h-4 text-orange-400 shrink-0" />
                      <span className="uppercase tracking-widest text-[10px]">{vet.specialty}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <a href={`tel:${vet.phone}`} className="p-4 bg-white dark:bg-slate-900 rounded-2xl text-slate-700 dark:text-white border border-slate-200 dark:border-slate-700 hover:text-orange-600 hover:border-orange-200 hover:scale-110 transition-all shadow-sm">
                      <Phone className="w-5 h-5" />
                    </a>
                    <a href={`mailto:${vet.email}`} className="p-4 bg-white dark:bg-slate-900 rounded-2xl text-slate-700 dark:text-white border border-slate-200 dark:border-slate-700 hover:text-orange-600 hover:border-orange-200 hover:scale-110 transition-all shadow-sm">
                      <Mail className="w-5 h-5" />
                    </a>
                    <button className="flex-1 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] hover:scale-[1.05] active:scale-95 transition-all shadow-lg">Schedule Visit</button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {filteredVets.length === 0 && (
            <div className="md:col-span-2 py-32 text-center border-4 border-dashed border-slate-100 dark:border-slate-800 rounded-[4rem]">
               <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                 <Stethoscope className="w-10 h-10 text-slate-300 dark:text-slate-600" />
               </div>
               <h3 className="text-2xl font-black text-slate-400 dark:text-slate-600">No Providers Found</h3>
               <p className="text-sm font-bold text-slate-300 dark:text-slate-700 mt-2 max-w-sm mx-auto">Build your pet's healthcare team by adding your primary care vet or behavioral specialist.</p>
               {!isEditing && (
                 <button onClick={() => handleEdit()} className="mt-10 px-10 py-4 bg-slate-900 dark:bg-slate-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-600 transition-all shadow-xl active:scale-95">Add First Provider</button>
               )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VetHub;
