# 🐾 PetCare Dashboard - Deployment Guide

## Quick Start: Deploy to GitHub Pages

### Step 1: Push to GitHub

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit changes
git commit -m "Initial commit - PetCare Dashboard"

# Create a new repository on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git branch -M main
git push -u origin main
```

### Step 2: Configure GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** → **Pages**
3. Under "Build and deployment":
   - Source: **GitHub Actions**
4. Save the changes

### Step 3: Add Your Gemini API Key (Optional)

The app works without an API key, but AI features require it:

1. Go to **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `GEMINI_API_KEY`
4. Value: Your Gemini API key from [Google AI Studio](https://aistudio.google.com/app/apikey)
5. Click **Add secret**

### Step 4: Deploy

Push any change to the `main` branch to trigger deployment:

```bash
git add .
git commit -m "Deploy to GitHub Pages"
git push
```

The workflow will automatically build and deploy your site. Check the **Actions** tab to monitor progress.

Your site will be live at: `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/`

---

## 🔧 Local Development

### Install Dependencies

```bash
npm install
```

### Set Up Environment Variables (Optional)

Create a `.env.local` file:

```
GEMINI_API_KEY=your_api_key_here
```

### Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

### Build for Production

```bash
npm run build
```

The built files will be in the `dist/` folder.

### Preview Production Build

```bash
npm run preview
```

---

## 🐛 Troubleshooting

### White Screen Issues

**Common causes and fixes:**

1. **Base Path Issue**: If deploying to a subdirectory (not root domain), update `vite.config.ts`:
   ```typescript
   base: '/YOUR_REPO_NAME/', // Instead of './'
   ```

2. **Build Errors**: Check the Actions tab on GitHub for build logs
   ```bash
   # Test build locally first
   npm run build
   ```

3. **API Key Not Working**: 
   - Verify the secret is named exactly `GEMINI_API_KEY`
   - Check it's added under Repository Settings → Secrets → Actions
   - Redeploy after adding the secret

4. **Missing Dependencies**: 
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

### Page Not Updating

1. Force a new deployment:
   ```bash
   git commit --allow-empty -m "Trigger deployment"
   git push
   ```

2. Clear browser cache or open in incognito mode

3. Check GitHub Pages settings are correct (Actions as source)

### Console Errors

Open browser DevTools (F12) and check the Console tab for specific errors.

---

## 📁 Project Structure

```
petcare-dashboard/
├── .github/
│   └── workflows/
│       └── deploy.yml          # GitHub Actions deployment
├── components/                 # React components
│   ├── AlertsPanel.tsx
│   ├── BehavioralCharts.tsx
│   └── ...
├── services/
│   └── geminiService.ts        # AI integration
├── App.tsx                     # Main app component
├── index.html                  # HTML entry point
├── index.tsx                   # React entry point
├── vite.config.ts              # Build configuration
├── package.json                # Dependencies
└── README.md                   # This file
```

---

## 🚀 Advanced Configuration

### Custom Domain

1. Add a `CNAME` file to `public/` folder with your domain:
   ```
   yourdomain.com
   ```

2. Configure DNS records with your domain provider

3. In GitHub Settings → Pages, add your custom domain

### Environment Variables in Production

To use different API keys for dev/prod:

```typescript
// In your code
const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
```

### Optimization

The build is already optimized with:
- Code splitting
- Asset compression
- Tree shaking
- Minification

---

## 📝 Features

- 🐶 Multi-pet management
- 📊 Well-being score tracking
- 🤖 AI-powered insights (requires API key)
- 📱 Responsive design
- 🌙 Dark mode support
- 📅 Routine tracking
- 💊 Vet & insurance management
- 🛍️ Pet marketplace

---

## 🆘 Need Help?

- Check the [Actions tab](https://github.com/YOUR_USERNAME/YOUR_REPO_NAME/actions) for build logs
- Review [Vite documentation](https://vitejs.dev/)
- Check [GitHub Pages documentation](https://docs.github.com/en/pages)

---

## 📄 License

This project is open source and available for personal and commercial use.
