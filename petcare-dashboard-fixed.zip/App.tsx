
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import SummaryBar from './components/SummaryBar';
import ScoreBreakdown from './components/ScoreBreakdown';
import AlertsPanel from './components/AlertsPanel';
import RoutineTracker from './components/RoutineTracker';
import BehavioralCharts from './components/BehavioralCharts';
import Marketplace from './components/Marketplace';
import PetProfileCard from './components/PetProfileCard';
import VetHub from './components/VetHub';
import InsuranceHub from './components/InsuranceHub';
import SettingsHub from './components/SettingsHub';
import VideoCreator from './components/VideoCreator';
import PetSelectionHub from './components/PetSelectionHub';
import DaycareHub from './components/DaycareHub';
import { 
  MOCK_PETS,
  MOCK_SCORE, 
  MOCK_ALERTS, 
  MOCK_ROUTINE, 
  MOCK_BEHAVIOR, 
  MOCK_MARKETPLACE,
  MOCK_INSURANCE,
  MOCK_VETS,
  MOCK_WELLBEING_ACTIVITIES,
  MOCK_DAYCARE_BOOKINGS,
  MOCK_SCORE_HISTORY_MONTH
} from './constants';
import { 
  EmotionalState, 
  RoutineItem, 
  PetProfile, 
  InsurancePolicy, 
  VetProfile, 
  WellBeingScore, 
  WellBeingActivity, 
  BehaviorPrediction, 
  PetCustomAttribute,
  PetCategory,
  PetVideo,
  DaycareBooking,
  ScoreHistoryPoint
} from './types';
import { getSmartInsights, getBehavioralPrediction, getDeepThinkingInsight } from './services/geminiService';
import { 
  Sparkles, Activity, ShieldPlus, Stethoscope, User, Settings, Search, Menu, 
  Heart, ShoppingCart, Plus, Edit2, Phone, Mail, ExternalLink, ShieldCheck, 
  Trash2, MapPin, Check, X, LogOut, Moon, Sun, ChevronRight, Dog, Cat, Bird, Fish, HelpCircle,
  Video, BrainCircuit, Loader2, Briefcase
} from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<'login' | 'selection' | 'dashboard'>('login');
  const [darkMode, setDarkMode] = useState(false);
  const [pet, setPet] = useState<PetProfile>(MOCK_PETS[0]);
  const [activeTab, setActiveTab] = useState('Overview');
  const [emotionalState, setEmotionalState] = useState<EmotionalState>('Happy');
  const [smartInsight, setSmartInsight] = useState<string>('Analyzing your pet\'s well-being data...');
  const [isDeepThinking, setIsDeepThinking] = useState(false);
  const [behaviorPrediction, setBehaviorPrediction] = useState<BehaviorPrediction | null>(null);
  const [isPredicting, setIsPredicting] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Core App States
  const [allPets, setAllPets] = useState<PetProfile[]>(MOCK_PETS);
  const [routine, setRoutine] = useState<RoutineItem[]>(MOCK_ROUTINE);
  const [insurance, setInsurance] = useState<InsurancePolicy>(MOCK_INSURANCE);
  const [vets, setVets] = useState<VetProfile[]>(MOCK_VETS);
  const [videos, setVideos] = useState<PetVideo[]>([]);
  const [daycareBookings, setDaycareBookings] = useState<DaycareBooking[]>(MOCK_DAYCARE_BOOKINGS);
  const [wellBeingScore, setWellBeingScore] = useState<WellBeingScore>(MOCK_SCORE);
  const [wellBeingActivities, setWellBeingActivities] = useState<WellBeingActivity[]>(MOCK_WELLBEING_ACTIVITIES);
  const [scoreHistory, setScoreHistory] = useState<ScoreHistoryPoint[]>(MOCK_SCORE_HISTORY_MONTH);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // SCORING ENGINE: Automatically updates scores based on routine and activity changes
  useEffect(() => {
    // 1. Calculate Routine Score based on completion percentage
    const completedRoutine = routine.filter(r => r.status === 'Completed').length;
    const routinePercent = routine.length > 0 ? Math.round((completedRoutine / routine.length) * 100) : 100;

    // 2. Base metrics from initial score but modified by recent activities
    // We'll calculate a "delta" based on impacts of activities added this session
    const getMetricDelta = (category: string) => {
      return wellBeingActivities
        .filter(a => a.category === category)
        .reduce((acc, act) => {
          if (act.impact === 'Positive') return acc + 5;
          if (act.impact === 'Negative') return acc - 10;
          return acc;
        }, 0);
    };

    const updatedMetrics = wellBeingScore.metrics.map(m => {
      let newVal = m.value;
      if (m.label === 'Routine') newVal = routinePercent;
      else newVal = Math.min(100, Math.max(0, m.value + getMetricDelta(m.label)));
      
      return { ...m, value: newVal };
    });

    // 3. Overall Weighted Score
    const overall = Math.round(updatedMetrics.reduce((acc, m) => acc + (m.value * (parseInt(m.weight) / 100)), 0));

    const newScore = { overall, metrics: updatedMetrics };
    
    // Only update if actually different to prevent infinite loops
    if (JSON.stringify(newScore) !== JSON.stringify(wellBeingScore)) {
      setWellBeingScore(newScore);

      // 4. Update the LATEST point in history to reflect current score changes
      setScoreHistory(prev => {
        const last = prev[prev.length - 1];
        const updatedLast = {
          ...last,
          Physical: updatedMetrics.find(m => m.label === 'Physical')?.value || last.Physical,
          Emotional: updatedMetrics.find(m => m.label === 'Emotional')?.value || last.Emotional,
          Behavioral: updatedMetrics.find(m => m.label === 'Behavioral')?.value || last.Behavioral,
          Routine: updatedMetrics.find(m => m.label === 'Routine')?.value || last.Routine,
        };
        return [...prev.slice(0, -1), updatedLast];
      });
    }
  }, [routine, wellBeingActivities]);

  const refreshBehaviorPrediction = useCallback(async () => {
    setIsPredicting(true);
    try {
      const prediction = await getBehavioralPrediction(pet, MOCK_BEHAVIOR);
      setBehaviorPrediction(prediction);
    } catch (err) {
      console.error("Failed to fetch behavior prediction:", err);
    } finally {
      setIsPredicting(false);
    }
  }, [pet]);

  useEffect(() => {
    if (view === 'dashboard') {
      const fetchData = async () => {
        const insight = await getSmartInsights(pet, wellBeingScore, MOCK_ALERTS);
        setSmartInsight(insight);
        refreshBehaviorPrediction();
      };
      fetchData();
    }
  }, [pet, wellBeingScore, refreshBehaviorPrediction, view]);

  const runDeepThinking = async () => {
    setIsDeepThinking(true);
    const deepInsight = await getDeepThinkingInsight(pet, wellBeingScore);
    setSmartInsight(deepInsight || smartInsight);
    setIsDeepThinking(false);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setView('selection');
  };

  const selectPet = (selectedPet: PetProfile) => {
    setPet(selectedPet);
    if (selectedPet.category === 'Fish') {
      setRoutine([]); 
    } else if (routine.length === 0) {
      setRoutine(MOCK_ROUTINE);
    }
    setView('dashboard');
    setActiveTab('Overview');
  };

  const handleAddPet = (category: PetCategory) => {
    const newPet: PetProfile = {
      id: Date.now().toString(),
      name: 'New ' + category,
      category,
      breed: 'Unknown',
      age: 0,
      size: 'Small',
      medicalNotes: [],
      imageUrl: category === 'Fish' ? 'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?auto=format&fit=crop&q=80&w=200&h=200' : 'https://images.unsplash.com/photo-1544568100-847a948585b9?auto=format&fit=crop&q=80&w=200&h=200',
      customAttributes: []
    };
    setAllPets([...allPets, newPet]);
    selectPet(newPet);
  };

  const handleAddAttribute = (key: string, value: string) => {
    const newAttr: PetCustomAttribute = { id: Date.now().toString(), key, value };
    const updatedPet = { ...pet, customAttributes: [...pet.customAttributes, newAttr] };
    setPet(updatedPet);
    setAllPets(allPets.map(p => p.id === pet.id ? updatedPet : p));
  };

  const handleDeleteAttribute = (id: string) => {
    const updatedPet = { ...pet, customAttributes: pet.customAttributes.filter(a => a.id !== id) };
    setPet(updatedPet);
    setAllPets(allPets.map(p => p.id === pet.id ? updatedPet : p));
  };

  const handleUpdatePet = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const updatedPet = {
      ...pet,
      name: formData.get('name') as string,
      breed: formData.get('breed') as string,
      age: Number(formData.get('age')),
      weight: Number(formData.get('weight')),
    };
    setPet(updatedPet);
    setAllPets(allPets.map(p => p.id === pet.id ? updatedPet : p));
    alert('Pet profile updated successfully!');
  };

  const handleSaveVet = (vetToSave: VetProfile) => {
    if (vets.find(v => v.id === vetToSave.id)) {
      setVets(vets.map(v => v.id === vetToSave.id ? vetToSave : v));
    } else {
      setVets([...vets, vetToSave]);
    }
  };

  const handleDeleteVet = (id: string) => {
    setVets(vets.filter(v => v.id !== id));
  };

  const navItems = [
    { id: 'Overview', icon: Activity },
    { id: 'Vet & Medical', icon: Stethoscope },
    { id: 'Daycare', icon: Briefcase },
    { id: 'Insurance', icon: ShieldPlus },
    { id: 'Marketplace', icon: ShoppingCart },
    { id: 'Cinema (Veo)', icon: Video },
    { id: 'Profile', icon: User },
    { id: 'Settings', icon: Settings },
  ];

  if (view === 'login') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-orange-50 dark:bg-slate-950 p-6 transition-colors duration-500">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl p-10 text-center border border-white/50 dark:border-slate-800 animate-in fade-in zoom-in duration-700">
          <div className="w-20 h-20 bg-orange-600 rounded-3xl flex items-center justify-center shadow-xl shadow-orange-200 dark:shadow-none mx-auto mb-8 animate-float">
            <Heart className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white mb-2">PetCare</h1>
          <p className="text-slate-500 dark:text-slate-400 mb-10 font-medium">Your pet's health, simplified.</p>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="text-left space-y-1">
              <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase px-1">Email Address</label>
              <input type="email" required defaultValue="parent@petcare.io" className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/30 outline-none dark:text-white transition-all" />
            </div>
            <div className="text-left space-y-1">
              <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase px-1">Password</label>
              <input type="password" required defaultValue="password123" className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl focus:ring-4 focus:ring-orange-100 dark:focus:ring-orange-900/30 outline-none dark:text-white transition-all" />
            </div>
            <button type="submit" className="w-full py-5 bg-orange-600 text-white rounded-[1.5rem] font-black text-lg shadow-xl shadow-orange-100 dark:shadow-none hover:bg-orange-700 active:scale-95 transition-all">
              Sign In
            </button>
          </form>
          <div className="mt-8 text-sm text-slate-400 font-bold">
            Don't have an account? <span className="text-orange-600 cursor-pointer">Register</span>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'selection') {
    return (
      <PetSelectionHub 
        pets={allPets}
        onSelect={selectPet}
        onAdd={handleAddPet}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col lg:flex-row font-sans antialiased text-slate-900 dark:text-slate-100 transition-colors duration-500">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex w-72 bg-white dark:bg-slate-900 border-r border-slate-100 dark:border-slate-800 flex-col sticky top-0 h-screen shadow-sm z-50">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-10 h-10 bg-orange-600 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-100 dark:shadow-none">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">PetCare</span>
          </div>

          <nav className="space-y-1.5">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-4 px-5 py-3.5 rounded-2xl text-sm font-bold transition-all ${
                  activeTab === item.id 
                    ? 'bg-orange-600 text-white shadow-xl shadow-orange-100 dark:shadow-none translate-x-1' 
                    : 'text-slate-400 dark:text-slate-500 hover:bg-orange-50 dark:hover:bg-slate-800 hover:text-orange-600'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.id}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto p-8 space-y-3">
          <button 
            onClick={() => setDarkMode(!darkMode)}
            className="w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs font-black uppercase text-slate-500 transition-all hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <div className="flex items-center gap-3">
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              {darkMode ? 'Light' : 'Dark'}
            </div>
          </button>
          
          <button 
            onClick={() => setView('selection')}
            className="w-full flex items-center gap-4 p-4 text-orange-600 bg-orange-50 dark:bg-orange-900/10 rounded-2xl text-xs font-black uppercase hover:bg-orange-100 transition-all"
          >
            <LogOut className="w-4 h-4" /> Switch Pet
          </button>
        </div>
      </aside>

      {/* Mobile Top Header */}
      <div className="lg:hidden flex items-center justify-between p-6 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 sticky top-0 z-[60]">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-orange-600 rounded-xl flex items-center justify-center">
            <Heart className="w-5 h-5 text-white" />
          </div>
          <span className="font-black text-lg">PetCare</span>
        </div>
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-white dark:bg-slate-950 p-8 pt-24 animate-in fade-in slide-in-from-top-4 duration-300">
          <nav className="space-y-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-lg font-black transition-all ${
                  activeTab === item.id 
                    ? 'bg-orange-600 text-white shadow-xl' 
                    : 'text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900'
                }`}
              >
                <item.icon className="w-6 h-6" />
                {item.id}
              </button>
            ))}
          </nav>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto px-4 py-8 md:px-10 overflow-y-auto">
        {/* Dashboard Header */}
        <header className="hidden lg:flex items-center justify-between mb-10 gap-6">
          <div className="flex-1 relative group max-w-lg">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-orange-600 transition-colors" />
            <input 
              type="text" 
              placeholder="Search health records, tips, food..." 
              className="w-full pl-12 pr-6 py-3.5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl text-sm focus:outline-none focus:ring-4 focus:ring-orange-50 transition-all shadow-sm font-medium dark:text-white"
            />
          </div>
          <div className="flex items-center gap-3 p-1.5 pr-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm transition-all cursor-pointer">
            <img src={pet.imageUrl} className="w-10 h-10 rounded-xl object-cover" alt={pet.name} />
            <div>
              <p className="text-xs font-black text-slate-900 dark:text-white leading-none mb-0.5">{pet.name}</p>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{pet.category}</p>
            </div>
          </div>
        </header>

        {/* Summary Bar */}
        <SummaryBar 
          pet={pet} 
          score={wellBeingScore} 
          emotionalState={emotionalState} 
          onEmotionChange={setEmotionalState}
          alertCount={MOCK_ALERTS.length} 
        />

        {/* Dynamic Hubs */}
        {activeTab === 'Overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-20">
            <div className="lg:col-span-8 space-y-6">
              <div className="bg-orange-600 dark:bg-orange-700 rounded-[2.5rem] p-6 md:p-10 text-white relative overflow-hidden shadow-2xl animate-in slide-in-from-left duration-700">
                <div className="relative z-10 max-w-lg">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-white/20 rounded-2xl backdrop-blur-md border border-white/30">
                        <Sparkles className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="font-black text-xl md:text-2xl tracking-tight">Health Intel Pulse</h3>
                    </div>
                    <button 
                      onClick={runDeepThinking}
                      disabled={isDeepThinking}
                      className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl border border-white/20 text-[10px] font-black uppercase transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isDeepThinking ? <Loader2 className="w-4 h-4 animate-spin" /> : <BrainCircuit className="w-4 h-4" />}
                      Deep Think
                    </button>
                  </div>
                  <p className="text-white/90 leading-relaxed text-base md:text-lg mb-8 font-bold">
                    {smartInsight}
                  </p>
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="px-5 py-2 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/20 backdrop-blur-sm">Gemini 3 Pro</span>
                    <span className="px-5 py-2 bg-amber-400 text-orange-900 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">AI Diagnosis</span>
                  </div>
                </div>
                <Activity className="absolute -bottom-16 -right-16 w-80 h-80 text-white/5 rotate-12" />
              </div>

              <BehavioralCharts 
                data={MOCK_BEHAVIOR} 
                prediction={behaviorPrediction} 
                isPredicting={isPredicting}
                onRefreshPrediction={refreshBehaviorPrediction}
              />
              
              <Marketplace items={MOCK_MARKETPLACE} />
            </div>

            <div className="lg:col-span-4 space-y-6">
              <PetProfileCard pet={pet} onAddAttribute={handleAddAttribute} onDeleteAttribute={handleDeleteAttribute} />
              <ScoreBreakdown 
                score={wellBeingScore} 
                history={scoreHistory}
                activities={wellBeingActivities} 
                onUpdateScore={setWellBeingScore} 
                onAddActivity={(act) => setWellBeingActivities([act, ...wellBeingActivities])} 
                onDeleteActivity={(id) => setWellBeingActivities(wellBeingActivities.filter(a => a.id !== id))} 
              />
              <AlertsPanel alerts={MOCK_ALERTS} />
              <RoutineTracker routine={routine} petCategory={pet.category} onUpdate={setRoutine} />
            </div>
          </div>
        )}

        {activeTab === 'Daycare' && (
          <DaycareHub 
            pet={pet} 
            bookings={daycareBookings} 
            onAddBooking={(b) => setDaycareBookings([b, ...daycareBookings])} 
            onCancelBooking={(id) => setDaycareBookings(daycareBookings.filter(b => b.id !== id))} 
          />
        )}

        {activeTab === 'Vet & Medical' && <VetHub vets={vets} onSave={handleSaveVet} onDelete={handleDeleteVet} />}
        
        {activeTab === 'Insurance' && <InsuranceHub policy={insurance} onUpdatePolicy={setInsurance} />}
        
        {activeTab === 'Marketplace' && <Marketplace items={MOCK_MARKETPLACE} />}
        
        {activeTab === 'Cinema (Veo)' && <VideoCreator videos={videos} onAddVideo={(v) => setVideos([v, ...videos])} onDeleteVideo={(id) => setVideos(videos.filter(v => v.id !== id))} />}
        
        {activeTab === 'Profile' && (
          <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in pb-20">
            <div className="bg-white dark:bg-slate-900 p-6 md:p-10 rounded-[3rem] shadow-sm border border-slate-100 dark:border-slate-800">
               <div className="flex flex-col md:flex-row items-center gap-8 mb-10">
                  <div className="relative">
                    <img src={pet.imageUrl} className="w-40 h-40 rounded-[2.5rem] object-cover ring-8 ring-orange-50 dark:ring-slate-800" />
                    <button className="absolute -bottom-2 -right-2 p-3 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100">
                      <Edit2 className="w-5 h-5 text-orange-600" />
                    </button>
                  </div>
                  <div className="text-center md:text-left">
                    <h2 className="text-4xl font-black mb-1">{pet.name}</h2>
                    <p className="text-slate-500 font-bold text-lg">{pet.breed} • {pet.age} Years • {pet.category}</p>
                  </div>
               </div>
               <form onSubmit={handleUpdatePet} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-2">Legal Name</label>
                    <input name="name" defaultValue={pet.name} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl outline-none focus:ring-4 focus:ring-orange-100" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-2">Breed / Species</label>
                    <input name="breed" defaultValue={pet.breed} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-2xl outline-none focus:ring-4 focus:ring-orange-100" />
                  </div>
                  <div className="md:col-span-2">
                    <button type="submit" className="w-full py-5 bg-orange-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-orange-100">Save Identity Changes</button>
                  </div>
               </form>
            </div>
            <PetProfileCard pet={pet} onAddAttribute={handleAddAttribute} onDeleteAttribute={handleDeleteAttribute} />
          </div>
        )}

        {activeTab === 'Settings' && <SettingsHub darkMode={darkMode} onToggleDarkMode={() => setDarkMode(!darkMode)} />}
      </main>
    </div>
  );
};

export default App;
