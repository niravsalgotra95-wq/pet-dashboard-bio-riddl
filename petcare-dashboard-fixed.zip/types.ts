
export type EmotionalState = 'Calm' | 'Happy' | 'Bored' | 'Stressed' | 'Anxious' | 'Aggressive';
export type PetCategory = 'Dog' | 'Cat' | 'Bird' | 'Reptile' | 'Fish' | 'Small Mammal';

export interface PetCustomAttribute {
  id: string;
  key: string;
  value: string;
}

export interface PetProfile {
  id: string;
  name: string;
  category: PetCategory;
  breed: string;
  age: number;
  size: 'Small' | 'Medium' | 'Large';
  weight?: number;
  medicalNotes: string[];
  imageUrl: string;
  customAttributes: PetCustomAttribute[];
}

export interface WellBeingMetric {
  label: string;
  value: number;
  weight: string;
  color: string;
  trend?: number;
}

export interface WellBeingScore {
  overall: number;
  metrics: WellBeingMetric[];
}

export interface ScoreHistoryPoint {
  date: string;
  Physical: number;
  Emotional: number;
  Behavioral: number;
  Routine: number;
}

export interface WellBeingActivity {
  id: string;
  category: 'Physical' | 'Emotional' | 'Behavioral' | 'Routine';
  description: string;
  impact: 'Positive' | 'Negative' | 'Neutral';
  timestamp: string;
}

export interface Alert {
  id: string;
  type: 'Health' | 'Emotional' | 'Behavioral' | 'Routine';
  severity: 'Low' | 'Medium' | 'High';
  cause: string;
  suggestion: string;
}

export type RoutineType = 'Feeding' | 'Walk' | 'Play' | 'Sleep' | 'Medicine' | 'Tank Cleaning' | 'Water Change' | 'Filter Check';

export interface RoutineItem {
  id: string;
  title: string;
  time: string;
  status: 'Completed' | 'Missed' | 'Upcoming';
  type: RoutineType;
}

export interface BehaviorDataPoint {
  day: string;
  barking: number;
  activity: number;
  rest: number;
}

export interface BehaviorPrediction {
  prediction: string;
  riskLevel: 'Low' | 'Medium' | 'High';
  explanation: string;
  preventiveAction: string;
}

export interface MarketplaceReview {
  user: string;
  rating: number;
  comment: string;
}

export interface MarketplaceItem {
  id: string;
  name: string;
  category: 'Food' | 'Toys' | 'Grooming' | 'Training' | 'Wearables' | 'Supplements';
  price: string;
  imageUrl: string;
  reason: string;
  reviews: MarketplaceReview[];
}

export interface InsurancePolicy {
  provider: string;
  policyNumber: string;
  coverageLimit: string;
  premium: string;
  renewalDate: string;
  status: 'Active' | 'Pending' | 'Expired';
  claims: InsuranceClaim[];
}

export interface InsuranceClaim {
  id: string;
  date: string;
  amount: string;
  description: string;
  status: 'Processing' | 'Approved' | 'Rejected';
}

export interface VetProfile {
  id: string;
  name: string;
  clinic: string;
  address?: string;
  specialty: string;
  phone: string;
  email: string;
  imageUrl: string;
  isEmergency: boolean;
}

export interface PetVideo {
  id: string;
  prompt: string;
  videoUrl: string;
  timestamp: string;
}

export interface DaycareBooking {
  id: string;
  serviceName: string;
  date: string;
  time: string;
  status: 'Scheduled' | 'Checked-in' | 'Completed' | 'Cancelled';
  price: string;
  notes?: string;
}

export interface DaycareService {
  id: string;
  name: string;
  description: string;
  price: string;
  duration: string;
}
