
import { PetProfile, WellBeingScore, Alert, RoutineItem, BehaviorDataPoint, MarketplaceItem, InsurancePolicy, VetProfile, WellBeingActivity, ScoreHistoryPoint, DaycareService, DaycareBooking } from './types';

export const MOCK_PETS: PetProfile[] = [
  {
    id: 'p1',
    name: 'Buddy',
    category: 'Dog',
    breed: 'Golden Retriever',
    age: 3,
    size: 'Large',
    weight: 32,
    medicalNotes: ['Sensitive stomach', 'Peanut allergy'],
    imageUrl: 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&q=80&w=200&h=200',
    customAttributes: [
      { id: '1', key: 'Microchip ID', value: '985-112-000-442' },
      { id: '2', key: 'Favorite Snack', value: 'Carrot sticks' }
    ]
  },
  {
    id: 'p2',
    name: 'Luna',
    category: 'Cat',
    breed: 'Siamese',
    age: 2,
    size: 'Medium',
    weight: 4.5,
    medicalNotes: ['Lactose intolerant'],
    imageUrl: 'https://images.unsplash.com/photo-1513245543132-31f507417b26?auto=format&fit=crop&q=80&w=200&h=200',
    customAttributes: [
      { id: '3', key: 'Indoor Only', value: 'Yes' }
    ]
  }
];

export const MOCK_SCORE: WellBeingScore = {
  overall: 78,
  metrics: [
    { label: 'Physical', value: 85, color: 'bg-blue-500', weight: '35%', trend: 5 },
    { label: 'Emotional', value: 65, color: 'bg-pink-500', weight: '30%', trend: -2 },
    { label: 'Behavioral', value: 70, color: 'bg-purple-500', weight: '25%', trend: 8 },
    { label: 'Routine', value: 90, color: 'bg-emerald-500', weight: '10%', trend: 0 },
  ]
};

export const MOCK_SCORE_HISTORY_MONTH: ScoreHistoryPoint[] = Array.from({ length: 30 }, (_, i) => ({
  date: `${i + 1}`,
  Physical: 70 + Math.floor(Math.random() * 25),
  Emotional: 55 + Math.floor(Math.random() * 35),
  Behavioral: 60 + Math.floor(Math.random() * 30),
  Routine: 85 + Math.floor(Math.random() * 10),
}));

export const MOCK_WELLBEING_ACTIVITIES: WellBeingActivity[] = [
  { id: 'wa1', category: 'Emotional', description: 'Played fetching for 30 mins', impact: 'Positive', timestamp: 'Today, 10:00 AM' },
  { id: 'wa2', category: 'Behavioral', description: 'Barking at mailman', impact: 'Negative', timestamp: 'Today, 11:30 AM' }
];

export const MOCK_ALERTS: Alert[] = [
  {
    id: '1',
    type: 'Emotional',
    severity: 'Medium',
    cause: 'Increased barking detected between 2-4 PM',
    suggestion: 'Possible boredom. Try adding a puzzle toy.'
  }
];

export const MOCK_ROUTINE: RoutineItem[] = [
  { id: '1', title: 'Breakfast', time: '08:00 AM', status: 'Completed', type: 'Feeding' },
  { id: '2', title: 'Morning Walk', time: '09:00 AM', status: 'Completed', type: 'Walk' },
];

export const MOCK_BEHAVIOR: BehaviorDataPoint[] = [
  { day: 'Mon', barking: 12, activity: 65, rest: 23 },
  { day: 'Tue', barking: 15, activity: 70, rest: 15 },
  { day: 'Wed', barking: 8, activity: 50, rest: 42 },
  { day: 'Thu', barking: 25, activity: 80, rest: 5 },
  { day: 'Fri', barking: 30, activity: 75, rest: 5 },
  { day: 'Sat', barking: 10, activity: 90, rest: 10 },
  { day: 'Sun', barking: 5, activity: 40, rest: 55 },
];

export const MOCK_MARKETPLACE: MarketplaceItem[] = [
  // --- Training ---
  {
    id: 'm1',
    name: 'Smart Clicker Pro',
    category: 'Training',
    price: '$19.99',
    imageUrl: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Perfect for correcting the afternoon barking patterns detected by AI.',
    reviews: [{ user: 'Alex G.', rating: 5, comment: 'Actually works!' }]
  },
  {
    id: 'm2',
    name: 'VR Agility Tunnel',
    category: 'Training',
    price: '$85.00',
    imageUrl: 'https://images.unsplash.com/photo-1591768575198-88dac53fbd0a?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Recommended to boost your pet\'s declining Physical score.',
    reviews: []
  },
  {
    id: 'm3',
    name: 'Scent Work Starter Kit',
    category: 'Training',
    price: '$29.99',
    imageUrl: 'https://images.unsplash.com/photo-1516733725897-1aa73b87c8e8?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Great for mental stimulation during rest periods.',
    reviews: []
  },
  // --- Supplements ---
  {
    id: 'm4',
    name: 'Hip & Joint Mobility Chews',
    category: 'Supplements',
    price: '$34.50',
    imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Essential for large breeds like Golden Retrievers.',
    reviews: [{ user: 'Doris P.', rating: 5, comment: 'Noticeable difference in 2 weeks.' }]
  },
  {
    id: 'm5',
    name: 'Omega-3 Salmon Oil',
    category: 'Supplements',
    price: '$22.00',
    imageUrl: 'https://images.unsplash.com/photo-1628134711291-b39775ff41bf?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Promotes coat health for Siamese cats.',
    reviews: []
  },
  {
    id: 'm6',
    name: 'Calm-Max Anxiety drops',
    category: 'Supplements',
    price: '$18.99',
    imageUrl: 'https://images.unsplash.com/photo-1544568100-847a948585b9?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Address the high Stressed emotional state trends.',
    reviews: []
  },
  // --- Food ---
  {
    id: 'm7',
    name: 'Freeze-Dried Raw Beef',
    category: 'Food',
    price: '$42.00',
    imageUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'High-protein diet to support increased activity levels.',
    reviews: []
  },
  {
    id: 'm8',
    name: 'Interactive Slow Feeder',
    category: 'Toys',
    price: '$15.99',
    imageUrl: 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Matches Buddy\'s sensitive stomach by preventing bloating.',
    reviews: []
  },
  // --- Toys ---
  {
    id: 'm9',
    name: 'Ultra-Tough Chew Ring',
    category: 'Toys',
    price: '$12.50',
    imageUrl: 'https://images.unsplash.com/photo-1548191265-cc70d3d45ba1?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Durable play for large, high-energy pets.',
    reviews: []
  },
  {
    id: 'm10',
    name: 'Automatic Laser Pointer',
    category: 'Toys',
    price: '$38.00',
    imageUrl: 'https://images.unsplash.com/photo-1513245543132-31f507417b26?auto=format&fit=crop&q=80&w=300&h=300',
    reason: 'Keep Luna active during your work hours.',
    reviews: []
  }
];

export const MOCK_INSURANCE: InsurancePolicy = {
  provider: 'PetGuard Platinum',
  policyNumber: 'PG-99210-AX',
  coverageLimit: '$15,000 / yr',
  premium: '$42.50 / mo',
  renewalDate: 'Oct 12, 2025',
  status: 'Active',
  claims: []
};

export const MOCK_VETS: VetProfile[] = [
  {
    id: 'v1',
    name: 'Dr. Sarah Thompson',
    clinic: 'Paws & Claws Clinic',
    address: '123 Pet Lane, Pawsburg',
    specialty: 'General Practice',
    phone: '(555) 123-4567',
    email: 'sarah.t@pawsclaws.com',
    imageUrl: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=100&h=100',
    isEmergency: false
  }
];

export const DAYCARE_SERVICES: DaycareService[] = [
  { id: 's1', name: 'Standard Daycare', description: 'Full day of play and socialization with expert supervision.', price: '$35.00', duration: '8 Hours' },
  { id: 's2', name: 'VIP Boarding', description: 'Overnight stay in luxury suites with 24/7 care.', price: '$65.00', duration: 'Overnight' },
  { id: 's3', name: 'Grooming & Spa', description: 'Full bath, brush, and nail trim for ultimate comfort.', price: '$45.00', duration: '2 Hours' },
  { id: 's4', name: 'One-on-One Training', description: 'Personalized obedience session with a certified trainer.', price: '$50.00', duration: '1 Hour' }
];

export const MOCK_DAYCARE_BOOKINGS: DaycareBooking[] = [
  { id: 'b1', serviceName: 'Standard Daycare', date: '2024-06-15', time: '08:00 AM', status: 'Scheduled', price: '$35.00' }
];
