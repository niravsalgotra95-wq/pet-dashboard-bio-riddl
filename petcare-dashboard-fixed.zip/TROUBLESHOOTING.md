# 🔧 White Screen Troubleshooting Checklist

## ✅ Pre-Deployment Checks

- [ ] Run `npm install` to ensure all dependencies are installed
- [ ] Test locally with `npm run dev` - does it work?
- [ ] Test build locally with `npm run build` - does it complete without errors?
- [ ] Test built version with `npm run preview` - does it load?

## ✅ GitHub Repository Setup

- [ ] Repository is public (or you have GitHub Pages enabled for private repos)
- [ ] All files are committed and pushed to GitHub
- [ ] `.github/workflows/deploy.yml` file exists in your repository

## ✅ GitHub Pages Configuration

- [ ] Go to Settings → Pages
- [ ] Source is set to "GitHub Actions" (NOT "Deploy from a branch")
- [ ] Wait 2-5 minutes after first deployment

## ✅ Build Status

- [ ] Go to Actions tab in your repository
- [ ] Check if the workflow ran successfully (green checkmark)
- [ ] If failed (red X), click on it to see error logs

## ✅ Common Issues & Fixes

### Issue: Workflow doesn't run automatically
**Fix:** 
```bash
git commit --allow-empty -m "Trigger deployment"
git push
```

### Issue: Build fails with "Cannot find module"
**Fix:**
```bash
# Delete and reinstall dependencies
rm -rf node_modules package-lock.json
npm install
git add package-lock.json
git commit -m "Update dependencies"
git push
```

### Issue: Page shows 404
**Fix:** Check `vite.config.ts` base path:
- For root domain: `base: './'`
- For subdirectory: `base: '/repo-name/'`

### Issue: White screen with no errors
**Fix:**
1. Open browser DevTools (F12)
2. Check Console tab for JavaScript errors
3. Check Network tab for failed resource loads
4. Try opening in incognito/private mode
5. Clear browser cache

### Issue: Environment variables not working
**Fix:**
1. GitHub Settings → Secrets and variables → Actions
2. Add secret named exactly `GEMINI_API_KEY`
3. Redeploy (push a new commit)

## ✅ Manual Testing Steps

1. **Check if site is live:**
   - URL should be: `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/`
   - Wait 5 minutes after first deployment

2. **Test the build locally:**
   ```bash
   npm run build
   cd dist
   python -m http.server 8000
   # Open http://localhost:8000
   ```

3. **Check browser console:**
   - Open DevTools (F12)
   - Look for any red error messages
   - Common errors:
     - "Failed to fetch" → Check API configuration
     - "Module not found" → Check imports and build
     - "Unexpected token" → Check if files are properly minified

## ✅ Verification Steps

After deployment, verify these work:
- [ ] Page loads without white screen
- [ ] Pet profiles are visible
- [ ] Navigation buttons work
- [ ] Dark mode toggle works
- [ ] Charts and graphs render
- [ ] No console errors in browser DevTools

## 🆘 Still Having Issues?

1. **Check the deployment logs:**
   - Go to repository → Actions tab
   - Click on latest workflow run
   - Expand each step to see detailed logs

2. **Compare with working example:**
   - Check if your vite.config.ts matches the template
   - Verify package.json has all required dependencies
   - Ensure index.html has correct script references

3. **Test with minimal changes:**
   ```bash
   # Reset to a clean state
   git stash
   npm run build
   # If this works, gradually add your changes back
   ```

## 📞 Getting Help

When asking for help, provide:
1. Link to your GitHub repository
2. Link to the live site (if deployed)
3. Screenshot of browser console errors
4. Screenshot of GitHub Actions logs (if build failed)
5. What you've already tried from this checklist
